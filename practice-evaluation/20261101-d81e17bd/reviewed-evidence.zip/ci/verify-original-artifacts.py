#!/usr/bin/env python3
"""Review original downloaded CI/release bytes without changing project evidence."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

p = argparse.ArgumentParser()
p.add_argument("--downloads", type=Path, required=True)
p.add_argument("--repo", type=Path, required=True)
a = p.parse_args()
result = {}
outer = a.downloads / "openflights-session-validation-41321256187-1.zip"
raw = outer.read_bytes()
if sha(raw) != "13e4a3cb97c1b8ecea86a80c2b698039b495163af467c6e9f7aa703d876e62d8":
    raise RuntimeError("OpenFlights producer artifact hash mismatch")
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    checked = []
    for name in z.namelist():
        if name.endswith("/"):
            continue
        if z.read(name) != (a.repo / "evidence/reproductions/20261101-ci-openflights-session/ci" / name).read_bytes():
            raise RuntimeError("Original OpenFlights artifact differs from Git evidence: " + name)
        checked.append(name)
    inner = z.read("openflights-evidence.zip")
    if sha(inner) != "2df17236c7f9ed91acded1525a1eb87ef04f756d40029ac01e1278ecf795c35a":
        raise RuntimeError("Inner exporter ZIP hash mismatch")
    with zipfile.ZipFile(io.BytesIO(inner)) as b:
        inner_checked = []
        for name in b.namelist():
            if name.endswith("/"):
                continue
            if b.read(name) != (a.repo / "evidence/reproductions/20261101-ci-openflights-session/bundle" / name).read_bytes():
                raise RuntimeError("Inner exporter differs from extracted Git evidence: " + name)
            inner_checked.append(name)
    result["openflights"] = {"outer_size": len(raw), "outer_sha256": sha(raw),
        "outer_files_identical_to_git": checked, "inner_sha256": sha(inner),
        "inner_files_identical_to_git": inner_checked}
snapshot = a.downloads / "snapshot-complete-41322953291.zip"
raw = snapshot.read_bytes()
if sha(raw) != "e7f883ccc00b186e286c7dc7e8bc7640bf24beb95714e4981ed9a38ac418f995":
    raise RuntimeError("Snapshot release asset hash mismatch")
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    expected = {}
    for line in z.read("SHA256SUMS.txt").decode().splitlines():
        digest, name = line.split(maxsplit=1)
        name = name.lstrip("*")
        expected[name] = digest
    entries = {n for n in z.namelist() if not n.endswith("/")}
    if entries != set(expected) | {"SHA256SUMS.txt"}:
        raise RuntimeError("Snapshot producer checksum coverage incomplete")
    for name, digest in expected.items():
        if sha(z.read(name)) != digest:
            raise RuntimeError("Snapshot producer checksum mismatch: " + name)
    git_checked = []
    for name in sorted(entries - {"build-a/package-inputs.tar", "build-b/package-inputs.tar"}):
        if z.read(name) != (a.repo / "evidence/reviews/20261101-snapshot-builds/attempt-3" / name).read_bytes():
            raise RuntimeError("Snapshot asset differs from Git selected evidence: " + name)
        git_checked.append(name)
    selected_inputs = []
    for build in ("build-a", "build-b"):
        with tarfile.open(fileobj=io.BytesIO(z.read(build + "/package-inputs.tar"))) as t:
            selected_inputs.append({member.name: sha(t.extractfile(member).read())
                for member in t.getmembers() if member.isfile()})
    if selected_inputs[0] != selected_inputs[1]:
        raise RuntimeError("Snapshot selected package-input file contents differ")
    result["snapshot"] = {"size": len(raw), "sha256": sha(raw),
        "producer_checksum_entries_verified": len(expected),
        "selected_git_files_byte_identical": git_checked,
        "package_input_regular_files_per_build": len(selected_inputs[0]),
        "package_input_file_contents_identical": True,
        "scope": "Selected package-input tree only; does not compare the complete image filesystem."}
print(json.dumps(result, indent=2))
