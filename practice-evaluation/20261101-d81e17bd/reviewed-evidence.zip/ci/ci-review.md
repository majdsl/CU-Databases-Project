# Independent CI and raw-artifact review

Assessed target: `d81e17bd92b67d29905a59ff1af2a22745f0187d` (remote main frozen by root).
Retrieved November 1, 2026, approximately 17:31–17:37 UTC, using the connected GitHub tools and ordinary TLS-verified HTTPS for the release ZIP.

## Actual completed runs and source identities

- [Correctness 41329137852](https://github.com/majdsl/CU-Databases-Project/actions/runs/41329137852): completed **success**, push to main, exact assessed SHA. Four successful jobs: offline normal/optimized reporting tests (105 each), five-engine integration, stock amd64 tutorial, native stock arm64 tutorial. Optional complete timed OpenFlights job **skipped**. Actual decoded logs retained as `job-124915348197.log`, `job-124915348295.log`, `job-124915347983.log`, and `job-124915348322.log`.
- Current five-engine log shows 146 lightweight tests normally, `SETUP PASS`, 146 under optimized Python, real identity/readback checks for all five engines, `OPENFLIGHTS SMOKE PASS`, and `TUTORIAL SMOKE PASS`. Stock jobs explicitly print `STOCK TUTORIAL PASS: amd64` and `...arm64`; arm64 is a four-engine stock path, not MyRocks coverage.
- [Complete OpenFlights 41321256187](https://github.com/majdsl/CU-Databases-Project/actions/runs/41321256187): completed **success**, all five jobs successful, older source `2da20124ca1e52128d7cb8c3536736ae139239f7`. Actual complete-session log retained as `job-124892079973.log`. It shows setup success, exactly five pilot trials, separately 25 full trials, pilot/full inspection success, clean exit/retained volume, export, extraction to another directory, checksum verification normally and under `-O`, and `OPENFLIGHTS SESSION WORKFLOW PASS`.
- Read raw pilot/full JSON: 5/25 trials respectively, each engine loads 67,663 routes, trial-level verified dataset fingerprint and actual DDL retained. Pilot is excluded from full statistics. These are shared-CI workflow-validation timings; power, governor and co-tenancy uncontrolled.
- Read frozen target workflow and evidence READMEs; used `git diff --exit-code 2da20124... d81e17b... -- benchmarks scripts/run_openflights.py scripts/archive_openflights.py compose.yaml Dockerfile docker/mariadb sql` and `git merge-base --is-ancestor`, both exit **0**. Relevant measured implementation is unchanged, but this remains an older execution rather than a fresh timed execution of target.

## Signed-snapshot reconstruction

Retrieved actual run metadata, job/step conclusions, and decoded logs for all three attempts; retained separately.

| Run | GitHub run head | Actual checkout/tested PR merge | Result |
| --- | --- | --- | --- |
| 41322017709 | d863f7b28a113c707a291b9d9c64ba01a7882cbf | 516defd8ca504f17de67b13c6f9c4d9afc27f8dc | Failure before five-engine worker; unsupported Compose option |
| 41322523394 | 752a87a482cf2690bf8088348ab56e2fae83c854 | 3d2cfa5efc59223bff7e981f6e2c37cd20fd4529 | Paired runtime/readback success; artifact omitted hidden checksummed file |
| 41322953291 | 41a39140b9d80e5ec64e3dd7710fe3501f0e558d | ab8cc6df8ac823011e9c797e86817d9d2f6ee568 | Paired runtime/readback success; complete archive |

The actual logs confirm both final uncached DB builds/readbacks and `PAIRED BUILD CORRECTNESS PASS`. Actual selected evidence agrees: package inventories and selected runtime configuration equal, image/config IDs and rootfs diff IDs unequal. One daemon, shared pinned base layers and one frozen runner; no timed workload and no complete image-filesystem byte comparison. These results support the bounded documentation claims, not byte-identical images or a full dependency lock.

## Original bytes independently downloaded and checked

GitHub connector download artifact 13088743843 (run 41321256187) returned original outer ZIP. Its SHA-256 is `13e4a3cb97c1b8ecea86a80c2b698039b495163af467c6e9f7aa703d876e62d8` (111,267 bytes), matching actual GitHub artifact metadata. All 14 entries are byte-identical to committed `evidence/reproductions/20261101-ci-openflights-session/ci/`. Its nested exporter ZIP is `2df17236c7f9ed91acded1525a1eb87ef04f756d40029ac01e1278ecf795c35a`, and all 15 nested entries match the committed extracted bundle.

The GitHub connector supports textual release metadata but not release binary downloads. Downloaded the [complete release ZIP](https://github.com/majdsl/CU-Databases-Project/releases/download/evidence-reconstruction-20261101/snapshot-complete-41322953291.zip) using ordinary proxy/TLS-preserving curl. Actual downloaded SHA-256 is `e7f883ccc00b186e286c7dc7e8bc7640bf24beb95714e4981ed9a38ac418f995` (103,595,175 bytes), matching GitHub release asset metadata and repository index.

Independent verification script `verify-original-artifacts.py` exited **0**, checked complete snapshot producer checksum coverage (30 entries plus manifest), all 29 selected Git-index files against original ZIP bytes, and matching contents of 46 regular package-input files per build. Large package-input TARs are correctly absent from the selected Git index and remain in the release archive. See `original-artifact-verification.json`.

Original downloaded ZIPs are retained separately under `../downloads/` relative to assessment root, outside the submitted source and outside the publication artifact directory; original public asset URLs/hashes are recorded here. No archive was edited or extracted over tracked evidence. The temporary connector download URL was used only to materialize original bytes and is intentionally absent from saved/public artifacts.

## Retrieval commands/tools and limits

- Connected `github_fetch` for run metadata and release metadata; `github_fetch_workflow_run_jobs` for completed job/step conclusions.
- Connected `github_fetch_workflow_job_logs` for eight actual job logs (listed above and three snapshot jobs).
- Connected `github_fetch_workflow_run_artifacts` and `github_download_workflow_artifact` for actual original OpenFlights artifact metadata/bytes.
- `curl --fail --location --silent --show-error <public complete release ZIP URL> --output <outside-source downloads path>`: exit 0.
- `python3 artifacts/ci/verify-original-artifacts.py --downloads downloads --repo repo`: exit 0.
- Git comparisons above: exit 0. No workflow dispatched, no SQL or paired builds personally executed by this agent, no benchmark rerun.
- Masked GitHub tokens in original logs remain masked. Reviewed credential/private-key and signed-URL patterns: retained logs contain masked auth headers and literal environment-variable references, not credential values; public CI machine paths are retained. No redactions needed in these fetched CI logs.
- Checksums and byte comparison establish integrity/correspondence. Actual fetched CI logs establish the scope of recorded CI execution; they are not independent physical-machine reproduction or authentication of historical author-run measurements.
