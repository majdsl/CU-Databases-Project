# Implementation, documentation and tutorial source review

Frozen source: `d81e17bd92b67d29905a59ff1af2a22745f0187d`, detached fresh clone of remote main. Review date 2026-11-01. Source inspection only here; execution and completed CI are handled separately. No project files edited. Prior assessment reports were not opened or used as targets.

## Scope personally inspected

README.md; docs/setup.md; docs/tutorial.md; docs/stock-tutorial-validation.md; docs/engine-recommendations.md; docs/team-contributions.md; compose.yaml; Dockerfile; docker/mariadb/Dockerfile; .github/workflows/correctness.yml; scripts/setup_project.py; scripts/init_env.py; scripts/check_environment.py; scripts/check_tutorial.py; scripts/check_stock_tutorial.py; scripts/tutorial_checks.py; scripts/tutorial_transactions.py; benchmarks/core.py; benchmarks/run.py; benchmarks/concurrency.py; benchmarks/openflights.py; benchmarks/memory_indexes.py; representative schemas and tests (tests/test_setup.py, tests/test_baseline.py, report-tests/test_tutorial_transactions.py), plus broad SQL/credentials/source inventories.

Read-only commands used: git rev-parse HEAD; rg --files for instruction/source inventories; wc -l and sed/cat for the named sources; rg -n for SQL execution, credentials, definitions and headings; git ls-files -z plus Python extension/path counting; ast.parse across tests/ and report-tests/ to count declared test methods and detect empty methods. No Docker or benchmark command run by this reviewer.

## Documentation evidence

- README first line explicitly identifies area 6, “Choosing the right storage engine”; root README is usable and project code is on main.
- README:10 shows a concrete five-engine tradeoff table, explicitly distinguishing OpenFlights time units/variance from separate synthetic disk-growth measurements; README:27 explains mechanisms and interpretation boundaries. Recommendations are conditional and directly usable, with full evidence links in docs/engine-recommendations.md:15.
- README:177 reasons about source-row keys, duplicate route preservation, nullable IDs, integer money, explicit BTREE and common logical schemas. These are explained design choices, not merely DDL screenshots.
- README:204 and docs/report-reproducibility.md connect experiment-specific methods, findings, raw evidence and report regeneration. The root page's broad documentation is substantial; its length and many linked historical records impose navigation effort, but an explicit start/tutorial/read-without-installing path is present.
- README:233 and docs/team-contributions.md explain the three members' completed roles, contributions and AI assistance. Source documents cannot independently authenticate human contribution claims; the rubric asks that the team be documented, which it is.

## Setup and safety claims checked against implementation

Claim | Source/method | Personally checked | Limit
--- | --- | --- | ---
One wrapper command after prerequisites | README:91–105; docs/setup.md:101; scripts/setup_project.py:43 | Actual sequence checks architecture/Compose, generates or preserves credentials, fetches data, builds runner, probes output writes, runs tests, builds/starts DB, verifies actual five engines and rows, prints SETUP PASS only at end | Requires installed Git/Python/Docker and Linux amd64; network and disk are genuine prerequisites
Native Linux access | docs/setup.md:58; scripts/setup_project.py:13; Dockerfile:22 | Runner USER is 10001:10001. Docs give scoped nonrecursive setfacl for results; setup prints quoted commands and missing-acl hint before credentials/download/build, then uses actual runner write probe | Rootless/remapped/SELinux cases correctly deferred to host configuration; setup does not automatically alter ownership
Local credential handling | scripts/init_env.py:7,13; compose.yaml:6–9,29 | secrets.token_hex(32) for both generated passwords, exclusive file creation, mode0600 at creation, preserves existing file, Compose environment expansion, no published DB port | An existing .env's original access permissions are deliberately retained; docs tell POSIX/Windows owners to inspect them
Integration claims | scripts/check_environment.py:10 | Requires MariaDB version string, SHOW ENGINES available identity, fixed per-engine DDL, information_schema actual engine check, parameterized row inserts including apostrophe, exact row contents, only created setup_probe cleanup | This is three-row engine correctness, not performance or durability; correctly labelled
Collision/failure handling | setup wrapper, benchmark run/trial functions, scripts/check_stock_tutorial.py | Existing benchmark tables are refused; worker failures are retained, no uncertain-write retries; stock tutorial validates ownership and random resource names; setup stops first failed subprocess | Default normal lab uses fixed cu-engine-lab, and docs explicitly warn a second clone is not isolation

## Tutorial value and capability

docs/tutorial.md is a reusable sequence with exact SQL files and expected observations: same table/50,000 rows on four common engines and optional ROCKSDB; engine self-description; MEMORY HASH equality/ref vs range/ALL and BTREE range; concurrent writers with before/after global lock counters; exact two-row COMMIT/ROLLBACK balances; clean-restart MEMORY volatility; cleanup preserving unrelated sentinel in automated checks.

sql/tutorial/05-lock-demo.sql deliberately uses static CASE-selected per-engine UPDATE statements, validates engine/row/duration, verifies affected-row count and reports microsecond server intervals. docs/tutorial.md:143 explicitly cautions that manual session launch does not guarantee overlap and zero waits do not prove general freedom from contention. scripts/tutorial_checks.py checks counters, interval overlap and exact state rather than imposing a timing-based ranking.

sql/tutorial/05b-transactions.sql and 05c-myrocks-transactions.sql use identical transactions for all five engines, distinguish rollback from commit, refuse pre-existing transaction-demo tables and drop only their own created tables. scripts/tutorial_transactions.py validates actual engine and every individual balance outcome; total-balance invariance alone is intentionally insufficient. report-tests/test_tutorial_transactions.py contains semantic mutation cases, missing/duplicate/malformed observations, and source-path checking.

Path B is honestly limited to four common engines with a pinned official multi-platform image. docs/stock-tutorial-validation.md distinguishes native Linux amd64/ARM64 CI, an owner's Windows CLI observation, the later transaction addition, and unvalidated interactive PowerShell/macOS/fresh Windows setup. No five-engine ARM claim found. scripts/check_stock_tutorial.py generates in-memory passwords, checks native/image architecture, mounted source hashes, owned resources and cleanup, saves redacted logs and never uses the lab .env.

## Tests, CI and mandatory rubric deductions

Static AST inventory: 26 test source files, 251 declared test methods, zero empty test methods; this is a source count, not a run result. The executable counts and success/failure are a separate agent's actual evidence. Tests include meaningful corrupted/missing row and checksum cases, invalid configuration, balanced scheduling, trial-weighting, engine substitution, pre-existing table preservation, setup failure ordering and transaction semantic corruption. Mocking Docker/database in offline tests is appropriate and complemented by real five-engine and native stock-tutorial jobs in .github/workflows/correctness.yml.

No hardcoded operational credential, debug-server mode, empty test file presented as a test, or demonstrated schema/code mismatch found in the inspected implementation.

Important precision for the SQL-interpolation deduction: f-strings **do exist** in benchmarks/openflights.py:20–24,104,109,132. They interpolate only the fixed source constants TABLE='openflights_routes' and COLUMNS; all external row/query values remain PyMySQL %s parameters. Engine choice is allowlisted by ddl(engine) and reads reviewed static DDL, and tutorial engine selection is static CASE SQL. Other “EXPLAIN ” concatenations prefix fixed reviewed query text. Therefore no unsafe interpolation of data or unvalidated identifiers was found. An assessment should not inaccurately claim there is no SQL string formatting; whether the official phrase is interpreted mechanically beyond its security purpose must be explicit.

## Improvements that would support still broader usability/depth claims

- Independently record a fresh physical-host newcomer installation/walkthrough, especially interactive PowerShell/macOS, keeping it distinct from CI and an owner-checkout CLI validation. This is a remaining validation limit, not an official automatic blocker.
- Preserve a shorter reader path to the latest validated source/evidence amid many historical archives; the current README/handoff already provide useful entry points.
- Deeper transaction/isolation/failure demonstrations (interrupted commits, deadlocks, foreign-key behavior), RAM exhaustion/repopulation, and steady-state compaction would expand an already extensive feature tutorial. Their absence does not negate the actual five-engine behavior, index, locking, compression and cache-pressure experiments.

## File counts and classification

See file-counts.json and test-source-inventory.json. `git ls-files` yields 1,369 tracked files total. Excluding evidence/ and provenance/, current project material is 207 files: 67 Python, 26 SQL, 45 Markdown, 9 YAML/YML, 3 Dockerfiles, 32 PNG/SVG figures, plus manifests/data/config. Archived-source bucket (all provenance/ plus evidence paths containing /source/) is 57 files; remaining historical evidence is 1,105 files, dominated by809 JSON records,113 text logs/snapshots and69 .log files. The evidence bucket also includes verifier scripts and bundled demonstration SQL, so these are not additional current harness source.

## Assessment boundary

No final criterion scores assigned here. Source claims and known limitations have been checked; CI execution authentication and fresh offline check results belong to their own preserved records. This review did not run SQL or install/build containers.

