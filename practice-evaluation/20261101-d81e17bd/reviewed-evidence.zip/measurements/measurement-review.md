# Fresh measurement and numerical-provenance review

Review date: 2026-11-01 (Europe/Berlin). Assessed detached HEAD:
`d81e17bd92b67d29905a59ff1af2a22745f0187d`.
This subreview inspected source and archived observations, executed independent
arithmetic/metadata/byte checks, and inspected representative figures. It executed
no SQL and no Docker/performance workload. Historical assessment scores and
conclusions were not consulted.

## Result

The core Area 6 measurement criteria are substantially evidenced. Five common
logical schemas differ only in engine selection; OpenFlights gives actual reference
data, while synthetic data fills its lack of events/updates/acknowledgment streams.
The main comparisons measure repeated loading, primary and secondary-index access,
full scans, concurrent writes, stopped-server allocation and restart survival.
Specific mechanism studies add MEMORY HASH/BTREE, InnoDB pool pressure and MyRocks
codec/SST metadata. No substantive numerical contradiction was found in the
independently checked headline claims.

## Claim-to-evidence map

| Claim | Implementing source / documented method | Raw identity and producing source | Personally checked | Inference / limitation |
| --- | --- | --- | --- | --- |
| Same logical schema and query stream on five engines | `sql/openflights/*.sql`, `sql/benchmark/*.sql`; `benchmarks/openflights.py:52-132`; `benchmarks/core.py:58`; `docs/openflights-method.md` | `evidence/openflights/20261009T160813Z-openflights-6884f225/results.json`; its 28 source fingerprints match Git source `bf4a35ac01fde21bb998cb4b0c407b0611d46325`; archive commit `77faef06e9718670137a610546aacc0f2b98b0f0` | Independently normalized all ten submitted schemas, parsed pinned CSV, regenerated canonical digest/oracle, checked all 25 trials' row hashes, query-stream equality within rounds, balanced engine positions, and saved point/source/scan plans | Source fingerprints establish source equivalence, not proof of the exact checkout commit executed. Physical structures and engine guarantees differ despite matched logical schemas. |
| MEMORY fastest observed route loading/scanning; MyISAM fastest persistent loading; Aria fastest persistent scanning | `benchmarks/openflights.py:105-159`; `benchmarks/run.py:measure`; `scripts/report_openflights_findings.py`; `README.md`, `docs/openflights-findings.md` | Same full OpenFlights run; separate pilot `20261009T152651Z-openflights-b44366ef` does not enter calculations | Independently recalculated means/sample SD from five trial observations per engine for load, and five within-trial means for each read metric; checked raw and derived statistics. All README rounded load/scan numbers match | Warm verification and explicit warmups; one reused server; client/protocol overhead included; configured caches and durability not equalized. Close overlapping lookup means support no universal ranking. |
| HASH range access scans while BTREE uses range access; 13.52x mean ratio at 100k/10-row range | `benchmarks/memory_indexes.py:95-159`; `docs/memory-index-method.md`, `docs/memory-index-findings.md` | `evidence/memory-indexes/20261016T170049Z-memory-indexes-d7d3b1c7/results.json`; 22 fingerprints match source-equivalent `8d2a8f4753cd306ba5bfc0791a35b7c62d84c0e3`; archive `7246f7e6907b5f4cf395f35c49389c9eecaedfda` | Recomputed all size/index/workload means/SD, exact ratio 13.5230216592, and all 72 diagnostic EXPLAIN/counter replays: HASH N+1 sequential requests, BTREE one key + 10/1000 next requests | Diagnostics replay only each trial/workload's first query. Unique integer keys, warm single client, fixed workload order; no duplicate-heavy keys, writes or RAM exhaustion tested. |
| Persistent datadir growth differs, while MEMORY allocation is RAM | `scripts/run_storage.py`, `benchmarks/storage.py`; `docs/storage-method.md`, `docs/storage-findings.md` | `evidence/storage/20261006T120404Z-storage-a5d23142/results.json`; host 3 + representative worker 18 fingerprints match `73ab5e9176dce9de7e40091a0c96e70647cb8e8a` (also archive commit) | Re-summed both stopped-server file inventories for every trial, both apparent and allocated metrics, verified all deltas/50 clean stop records. Mean allocated growth: InnoDB 9,572,352; Aria 3,911,680; MyISAM 1,327,104; ROCKSDB 1,224,704; MEMORY 126,976 bytes | Whole datadir includes logs, metadata and restart effects; no separate empty-workload subtraction. 10k synthetic rows do not yield bytes/route or physical SSD footprint. MEMORY disk value is overhead, not durable row storage. |
| All persistent engines preserve 1000 acknowledged rows in tested restarts; MEMORY loses all; forced MyISAM warnings remain | `scripts/run_recovery.py`, `benchmarks/recovery.py`; `docs/recovery-method.md`, `docs/recovery-findings.md` | `evidence/recovery/20261006T161514Z-recovery-99656d7e/results.json`; host 4 + representative writer 19 fingerprints match source-equivalent `520c70fa70c2d0654b2c7fe1215e2b0524d5f5b1`; archive `8037335c6d74c64bb3ca4567339804666e8bafb6` | Checked all 50 receipts' ordered ack IDs, stop codes/OOM flags, observed row counts/anomalies, every restart-log SHA-256, and all five forced MyISAM crash/repair warnings; independently calculated per-condition medians | Crash is between acknowledged statements after receipt/orchestration delay, process SIGKILL with kernel caches alive. No power loss, uncertain/open transaction, or interrupted commit claim. Timer includes Docker/observer/check work, unequal rows for MEMORY. |
| Larger InnoDB table exceeds 128MiB pool and incurs read activity; ~1.95x lookup ratio | `benchmarks/cache_pressure.py`, `scripts/run_cache_pressure.py`; cache-pressure method/findings | `evidence/cache-pressure/20261016T224612Z-cache-pressure-ca6cb57e/results.json`; measured-source snapshot `provenance/cache-pressure/`, revision `db0639c0194092e8c338a68f2f9f24ed024d7a5f` | Recomputed lookup/scan means and lookup ratio 1.9510042569; fixed before/after pool and fit/overflow checked for all 12 trials; reviewed read counters. Verified all 25 snapshot blobs/LF+CRLF hashes and pilot/full host/representative worker matches | Table size also changes B-tree shape/locality, and dirty-page histories differ. Read counters are global server windows, not physical SSD proof. A same-table/pool-size treatment would isolate pool capacity more closely. |
| Aria table waits persist on disjoint updates; MyISAM/MEMORY lose throughput at four clients | `benchmarks/write_diagnostics.py`, `scripts/run_write_diagnostics.py`, `benchmarks/concurrency.py:54-99`; write-diagnostics method/findings | `evidence/write-diagnostics/20261017T172951Z-write-diagnostics-773525b2/results.json`; measured snapshot `c000a91c410dba7e19f6e00be01da1e1b7b55300`; archive `b5eefc3` | Recomputed all 15 disjoint engine/client groups from five trials each, verified completion/rate arithmetic. Four-versus-two mean losses: MyISAM 46.1179791%, MEMORY 49.8397542%. Independently verified all 26 measured-source blobs/LF+CRLF hashes and pilot/full host/representative worker matches | Original full run has 150 trials; this independent numeric subset covers 75 disjoint trials. Global lock counters establish events, not elapsed-time attribution. DB CPU uses wider windows, short bursts are not sustained capacity, InnoDB zero waits is not absence of all contention. |
| ZSTD reduces repetitive SST bytes 95.15%, high-entropy only 0.44% | `benchmarks/rocksdb_compression.py:120-191,245-284`, `scripts/run_rocksdb_compression.py`; compression method/findings | `evidence/rocksdb-compression/20261027T220128Z-rocksdb-compression-ea876f45/results.json`; recorded measured Git SHA `cd3865136c8f466d3d19a5e327c578e033478778`; archive `7dd87e4fde8f015c1d5f5759f94c910e4804a807` | Recomputed all 32 trials' table-SST sums, eight-repeat group means/SD; reductions 95.1527351% and 0.4419798%. Checked entry coverage, requested actual SST codecs, layout stability and clean stops. Host 8/representative worker 25 hashes match recorded Git source | Automatic compaction disabled, bounded flush-only layout; 128MiB cache exceeds payload. Excludes WAL/server overhead and physical SSD footprint; timings do not isolate compression CPU. |

Older cases without `git_commit` in raw results are explicitly described as
**source-equivalent revisions**, found by checking every recorded fingerprint in
the named set against Git blobs with LF/CRLF tolerance. They are not relabeled as
fresh executions of the assessed SHA. Cache/write measured snapshots have their
own exact pinned historical revisions, separately from current report generators.

## Representative visual inspection

Personally viewed `docs/figures/openflights-load.png` and
`docs/figures/memory-index-access-paths.png`. Both are legible and identify units,
sample size, pilot exclusion and interpretation limits. OpenFlights shows the
individual trials and mean ± sample SD (explicitly not confidence intervals);
MEMORY shows diagnostic logical handler requests on a labeled log axis, with
N+1 versus key+range count values. The raw recalculations above support their
depicted numerical patterns.

## Source and method findings

- `benchmarks/core.py` uses seeded generation, deterministic balanced schedules
  and sample SD; no pooled-query false replication was found.
- `benchmarks/openflights.py` checks actual engine identity, full loaded content,
  deterministic query oracles, and actual EXPLAIN. Timed intervals exclude
  comparisons; generation/DDL/ANALYZE/full verification are outside route load time.
- `benchmarks/concurrency.py` starts timed work after a barrier, uses separate
  connections per worker, reports total completions / last completion wall time,
  checks exact final rows, and makes no automatic retry after uncertain outcomes.
- Inspected timed SQL values use placeholders. SQL f-strings in these paths
  assemble fixed module identifiers/column lists; `ddl(engine)` validates an
  engine against the closed five-engine allowlist before choosing a schema file.
- `provenance/cache-pressure/` and `provenance/write-diagnostics/` distinguish
  measured-source identities from today's evolving implementation. Image identity
  differences between separate pilot/full builds are disclosed rather than hidden.
- `docs/engine-recommendations.md` connects measurements to requirements, with
  transactions/foreign-key and MyRocks-isolation statements explicitly separated
  from measured performance. No unsupported universal winner was found.

## Concrete weaknesses and proportionate improvements

These are interpretation/usability improvements, not automatic unmet assignment requirements:

1. Historical raw OpenFlights, storage, recovery and MEMORY files record source
   fingerprints rather than an executed checkout SHA. Their exact source
   equivalence is recoverable, but recording Git SHA/dirty state and image selection
   at production time would make provenance simpler and stronger.
2. Original flight comparisons remain small, warmed, single-host and use unequal
   durability/cache budgets. Source/measurement scope is honest; broader production
   claims would need larger sustained workloads, separate client/server overhead,
   and controlled cache/durability treatments. Those studies are not prerequisites
   invented by this assessment.
3. Some historical method pages retain old progress wording:
   `docs/concurrency-method.md` still calls physical storage a pending experiment
   although the README and later storage findings show it completed; similarly
   the original baseline identifies later experiments as future work. Their dated
   scope limits explain much of this, but concise links to completed followups would
   reduce reader ambiguity.
4. Five or six repeats on a single laptop provide descriptive spread rather than
   independent-host uncertainty. Distinct cloud/CI runs must remain separate;
   a new physical-laptop reproduction is not established by this subreview.

No confirmed schema/code disagreement, hardcoded credential defect, unsafe data
interpolation, empty-test presentation or debug-mode defect was found within this
measurement-focused inspection. The parent review independently covers setup,
tutorial, tests and CI.

## Execution records and evaluator-script failure

- `logs/measurements-independent.log`: exit 1. This was an error in this
  evaluator's external script: its first schema normalization regex incorrectly
  used a double-escaped raw-pattern backslash, so it failed to remove ENGINE
  clauses. It was not a repository/schema defect. The failure log is preserved.
- The evaluator script alone was corrected outside the submitted repository.
  `logs/measurements-independent-corrected.log`: exit 0, 3.789 s. All scoped
  independent checks passed. No project code, tests, evidence or measurement was
  changed and no earlier passing project check was rerun to obtain a new score.
- `logs/measurements-source-identities.log`: exit 0, 2.246 s. Separate
  source-equivalence investigation, not a repeat of already passing arithmetic.
- `measurements/recompute.py`, `recomputed.json`,
  `reviewed-inputs-sha256.json`, `source-identities.py` and
  `source-identities.json` preserve the reproducible independent calculations,
  input byte hashes and source identity distinctions.

The only failure observed by this subtask was the evaluator-script escaping error.
All verified evidence remains historical evidence; byte integrity and arithmetic
agreement do not independently authenticate the producing machine or rerun SQL.

