"""Independent stdlib recalculation of representative archived claims; executes no SQL."""
import collections, csv, hashlib, io, json, math, pathlib, re, statistics, subprocess, sys

ROOT = pathlib.Path(sys.argv[1]).resolve()
OUT = pathlib.Path(__file__).parent
reviewed = {}
def load(relative):
    p = ROOT / relative
    b = p.read_bytes()
    reviewed[relative] = hashlib.sha256(b).hexdigest()
    return json.loads(b)
def need(ok, why):
    if not ok:
        raise ValueError(why)
def close(a, b, why):
    need(math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),why)
def describe(vals):
    return dict(n=len(vals),mean=statistics.mean(vals),sample_sd=statistics.stdev(vals))
def equal_describe(calc, saved, label):
    for k,v in calc.items():
        if k=="n":need(v==saved[k],label+" count")
        else:close(v,saved[k],label+" "+k)
def source_info(run):
    return {"run_id":run["run_id"],"git_commit":run.get("git_commit"),
            "recorded_source_hashes":len(run.get("source_sha256",{})),
            "status":run["status"],"trials":len(run["trials"])}

summary={"scope":"Fresh independent arithmetic, metadata and byte checks on archived observations; no SQL execution."}
# Schema parity of actual submitted DDL files.
for family in ("openflights","benchmark"):
    ddl=[]
    for p in sorted((ROOT/"sql"/family).glob("*.sql")):
        b=p.read_bytes();reviewed[str(p.relative_to(ROOT))]=hashlib.sha256(b).hexdigest()
        ddl.append(re.sub(r"ENGINE=\w+","ENGINE=ENGINE",b.decode()))
    need(len(ddl)==5 and len(set(ddl))==1,family+" schema parity")
summary["schema_parity"]={"openflights":5,"synthetic":5,"only_difference":"ENGINE clause"}

# Parse original input directly without importing the submitted parser.
raw=(ROOT/"data/openflights/routes.dat").read_bytes()
reviewed["data/openflights/routes.dat"]=hashlib.sha256(raw).hexdigest()
manifest=load("data/openflights/manifest.json")
need(len(raw)==manifest["bytes"] and reviewed["data/openflights/routes.dat"]==manifest["sha256"],"input bytes")
rows=[]
for i,r in enumerate(csv.reader(io.StringIO(raw.decode("utf-8"))),1):
    need(len(r)==9,"CSV field count")
    numeric=lambda x:None if x=="\\N" else int(x)
    rows.append((i,r[0],numeric(r[1]),r[2],numeric(r[3]),r[4],numeric(r[5]),r[6],int(r[7]),r[8]))
digest=hashlib.sha256()
for row in rows:
    digest.update((json.dumps(list(row),ensure_ascii=True,separators=(",",":"))+"\n").encode())
summary["data"]={"rows":len(rows),"canonical_sha256":digest.hexdigest(),
                 "scan_oracle":[len(rows),sum(r[8] for r in rows),sum(len(r[9]) for r in rows)]}

run=load("evidence/openflights/20261009T160813Z-openflights-6884f225/results.json")
saved=load("docs/data/openflights-statistics.json")
need(len(run["trials"])==25 and not run["config"]["pilot"],"full OpenFlights")
need(run["dataset_sha256"]==digest.hexdigest(),"transformed rows")
need(run["scan_oracle"]==summary["data"]["scan_oracle"],"scan oracle")
result={}
for engine in ("InnoDB","Aria","MyISAM","MEMORY","ROCKSDB"):
    trials=[t for t in run["trials"] if t["engine"]==engine]
    need(len(trials)==5 and {t["position"] for t in trials}==set(range(1,6)),"engine order balance")
    result[engine]={}
    for metric in ("load_seconds","lookup_ms","scan_ms","source_ms"):
        vals=[t[metric] if metric=="load_seconds" else statistics.mean(t[metric]) for t in trials]
        calc=describe(vals);equal_describe(calc,run["statistics"][engine][metric],"raw "+engine+" "+metric)
        equal_describe(calc,saved["full_statistics"][engine][metric],"derived "+engine+" "+metric)
        result[engine][metric]=calc
    for t in trials:
        need(t["verified_rows"]==len(rows) and t["verified_dataset_sha256"]==digest.hexdigest(),"trial data")
        need(t["explain"]["point"][0][5]=="PRIMARY" and t["explain"]["scan"][0][3]=="ALL"
             and t["explain"]["source"][0][5]=="source_destination","actual plans")
    for round_index in range(1,6):
        peers=[t for t in run["trials"] if t["round"]==round_index]
        need(len({tuple(t["lookup_ids"]) for t in peers})==1,"same lookup stream")
        need(len({tuple(t["source_ids"]) for t in peers})==1,"same source stream")
summary["openflights"]={"identity":source_info(run),"statistics":result,"all_actual_plans_match":True,
                         "loaded_and_verified_rows":sum(t["verified_rows"] for t in run["trials"])}

run=load("evidence/memory-indexes/20261016T170049Z-memory-indexes-d7d3b1c7/results.json")
result={}
for size in (10000,100000):
    result[size]={}
    for index in ("HASH","BTREE"):
        trials=[t for t in run["trials"] if t["rows"]==size and t["index"]==index]
        need(len(trials)==6,"MEMORY repeats")
        result[size][index]={}
        for label in ("equality","range_10","range_1000"):
            calc=describe([statistics.mean(t["timings_ms"][label]) for t in trials])
            equal_describe(calc,run["statistics"][str(size)][index][label],"MEMORY "+label)
            result[size][index][label]=calc
            for t in trials:
                d=t["diagnostics"][label];plan=d["explain"][0];delta=d["handler_read_delta"]
                if label=="equality":
                    need(plan["key"]=="probe_k" and plan["type"]=="ref","equality plan")
                    need(sum(delta.values())==2,"equality requests")
                elif index=="HASH":
                    need(plan["type"]=="ALL" and plan["key"] is None,"HASH range plan")
                    need(delta["Handler_read_rnd_next"]==size+1,"HASH full scan requests")
                else:
                    need(plan["type"]=="range" and plan["key"]=="probe_k","BTREE range plan")
                    need(delta["Handler_read_key"]==1 and delta["Handler_read_next"]==int(label.split("_")[1]),"BTREE requests")
    result[size]["HASH_div_BTREE"]={label:result[size]["HASH"][label]["mean"]/result[size]["BTREE"][label]["mean"]
        for label in ("equality","range_10","range_1000")}
summary["memory_indexes"]={"identity":source_info(run),"statistics":result,"72_plan_counter_replays_checked":True}

run=load("evidence/storage/20261006T120404Z-storage-a5d23142/results.json")
result={}
for t in run["trials"]:
    for phase in ("before","after"):
        need(t[phase+"_stop"]["ExitCode"]==0 and not t[phase+"_stop"]["OOMKilled"],"storage clean stop")
        for metric in ("allocated_bytes","apparent_bytes"):
            need(sum(f[metric] for f in t[phase]["files"] if f["counted"])==t[phase]["regular_file_"+metric],"inventory sum")
    for metric in ("allocated_bytes","apparent_bytes"):
        need(t["after"]["regular_file_"+metric]-t["before"]["regular_file_"+metric]==t["delta"]["regular_file_"+metric],"inventory difference")
for e in ("InnoDB","Aria","MyISAM","MEMORY","ROCKSDB"):
    trials=[t for t in run["trials"] if t["engine"]==e]
    result[e]=describe([t["delta"]["regular_file_allocated_bytes"] for t in trials])
    result[e]["MiB"]=result[e]["mean"]/2**20
summary["storage"]={"identity":source_info(run),"allocated_growth":result,"all_50_inventory_sums_checked":True}

run=load("evidence/recovery/20261006T161514Z-recovery-99656d7e/results.json")
result={}
for i,t in enumerate(run["trials"],1):
    need(t["acknowledgments"]["acknowledged_ids"]==list(range(1,1001)),"acknowledged IDs")
    need(t["stopped_state"]["ExitCode"]==(0 if t["mode"]=="clean" else 137) and not t["stopped_state"]["OOMKilled"],"recovery stop")
    observation=t["observation"];expected=0 if t["engine"]=="MEMORY" else 1000
    need(observation["status"]=="readable" and observation["intact_rows"]==expected and observation["observed_rows"]==expected,"recovery rows")
    need(not any(observation[k] for k in ("changed_ids","unexpected_ids","duplicate_ids")),"row anomalies")
    log_path=pathlib.Path("evidence/recovery")/run["run_id"]/t["restart_log"].replace("\\","/")
    log=(ROOT/log_path).read_bytes();reviewed[str(log_path)]=hashlib.sha256(log).hexdigest()
    need(reviewed[str(log_path)]==t["restart_log_sha256"],"restart log")
    if t["engine"]=="MyISAM" and t["mode"]=="sigkill":
        need(b"marked as crashed" in log and b"repair" in log,"MyISAM warning")
for engine in ("InnoDB","Aria","MyISAM","MEMORY","ROCKSDB"):
    result[engine]={}
    for mode in ("clean","sigkill"):
        ts=[t for t in run["trials"] if t["engine"]==engine and t["mode"]==mode]
        result[engine][mode]={"n":len(ts),"intact_rows":sorted({t["observation"]["intact_rows"] for t in ts}),
                             "median_seconds":statistics.median(t["restart_through_verification_seconds"] for t in ts)}
summary["recovery"]={"identity":source_info(run),"observations":result,"MyISAM_forced_warnings":5}

run=load("evidence/rocksdb-compression/20261027T220128Z-rocksdb-compression-ea876f45/results.json")
result={}
for profile in ("compressible","random"):
    result[profile]={}
    for codec in ("none","zstd"):
        ts=[t for t in run["trials"] if t["profile"]==profile and t["codec"]==codec]
        need(len(ts)==8,"compression repeats")
        for t in ts:
            need(t["clean_stop"]["ExitCode"]==0 and not t["clean_stop"]["OOMKilled"],"compression stop")
            files=t["table_sst"]["files"]
            need(sum(f["bytes"] for f in files)==t["table_sst"]["bytes"],"SST sum")
            need(sum(s["ENTRIES"] for s in t["sst_before_reads"])==65536,"SST entries")
            need(t["sst_before_reads"]==t["sst_after_reads"],"SST stability")
            need(all(s["COMPRESSION_ALGO"]==("NoCompression" if codec=="none" else "ZSTD") for s in t["sst_before_reads"]),"SST codec")
        result[profile][codec]=describe([t["table_sst"]["bytes"] for t in ts])
    result[profile]["reduction_percent"]=100*(1-result[profile]["zstd"]["mean"]/result[profile]["none"]["mean"])
summary["compression"]={"identity":source_info(run),"SST_statistics":result}

run=load("evidence/cache-pressure/20261016T224612Z-cache-pressure-ca6cb57e/results.json")
result={}
for size in (32768,262144):
    ts=[t for t in run["trials"] if t["rows"]==size]
    need(len(ts)==6,"cache repeats")
    for t in ts:
        need(t["buffer_pool_bytes"]==t["buffer_pool_after_bytes"]==134217728,"fixed pool")
        need((t["engine_reported_bytes"]<134217728)==(size==32768),"fits/overflows")
    result[size]={"lookup_ms":describe([statistics.mean(t["lookup_ms"]) for t in ts]),
                  "scan_ms":describe([statistics.mean(t["scan_ms"]) for t in ts]),
                  "lookup_pool_reads":[t["lookup_counters"]["delta"]["Innodb_buffer_pool_reads"] for t in ts]}
summary["cache_pressure"]={"identity":source_info(run),"statistics":result,
    "lookup_ratio":result[262144]["lookup_ms"]["mean"]/result[32768]["lookup_ms"]["mean"],
    "scan_ratio":result[262144]["scan_ms"]["mean"]/result[32768]["scan_ms"]["mean"]}

run=load("evidence/write-diagnostics/20261017T172951Z-write-diagnostics-773525b2/results.json")
result={}
for engine in ("InnoDB","Aria","MyISAM","MEMORY","ROCKSDB"):
    result[engine]={}
    for clients in (1,2,4):
        ts=[t for t in run["trials"] if t["engine"]==engine and t["clients"]==clients and t["pattern"]=="disjoint"]
        need(len(ts)==5,"write repeats")
        for t in ts:
            need(t["writes"]["completed"]==10000,"updates")
            close(t["writes"]["updates_per_second"],10000/t["writes"]["elapsed_seconds"],"throughput")
        result[engine][clients]={"updates_per_second":describe([t["writes"]["updates_per_second"] for t in ts]),
                               "table_waits_per_1000":describe([t["writes"]["lock_delta"]["Table_locks_waited"]/10 for t in ts])}
    result[engine]["two_to_four_loss_percent"]=100*(1-result[engine][4]["updates_per_second"]["mean"]/result[engine][2]["updates_per_second"]["mean"])
summary["write_diagnostics"]={"identity":source_info(run),"disjoint_groups":result}

# Measured source snapshots: reconstruct Git blob IDs and both newline SHA-256 forms.
snapshots={}
for kind,base,full,pilot in (
 ("cache-pressure","evidence/cache-pressure","20261016T224612Z-cache-pressure-ca6cb57e","20261016T224159Z-cache-pressure-fe05dc09"),
 ("write-diagnostics","evidence/write-diagnostics","20261017T172951Z-write-diagnostics-773525b2","20261017T170909Z-write-diagnostics-31a106d2")):
    manifest=load("provenance/"+kind+"/manifest.json")
    allowed={}
    for p,meta in manifest["files"].items():
        relative="provenance/"+kind+"/source/"+p
        raw=(ROOT/relative).read_bytes();reviewed[relative]=hashlib.sha256(raw).hexdigest()
        lf=raw.replace(b"\r\n",b"\n")
        need(hashlib.sha1(b"blob "+str(len(lf)).encode()+b"\0"+lf).hexdigest()==meta["git_blob_sha1"],"Git blob "+p)
        hashes={hashlib.sha256(lf).hexdigest(),hashlib.sha256(lf.replace(b"\n",b"\r\n")).hexdigest()}
        need(meta["sha256_lf"] in hashes and meta["sha256_crlf"] in hashes,"newline hashes "+p)
        allowed[p]=hashes
    for runid in (full,pilot):
        record=load(base+"/"+runid+"/results.json")
        for p,h in record["source_sha256"].items():need(h in allowed[p],"host source "+p)
        worker=record["trials"][0] if kind=="cache-pressure" else record["trials"][0]["prepare"]
        for p,h in worker["source_sha256"].items():need(h in allowed[p],"worker source "+p)
    snapshots[kind]={"revision":manifest["revision"],"files":len(manifest["files"]),"host_and_representative_worker_match":True}
summary["measured_source_snapshots"]=snapshots
OUT.mkdir(parents=True,exist_ok=True)
(OUT/"recomputed.json").write_text(json.dumps(summary,indent=2)+"\n")
(OUT/"reviewed-inputs-sha256.json").write_text(json.dumps(reviewed,indent=2,sort_keys=True)+"\n")
print("PASS independent recalculation: schemas, dataset, 25 OpenFlights trials, 72 MEMORY diagnostics, 50 storage inventories, 50 recovery logs, 32 compression trials, 12 cache-pressure trials, disjoint write groups, 51 measured source files.")
print(json.dumps({"OpenFlights_load":{e:v["load_seconds"] for e,v in summary["openflights"]["statistics"].items()},
 "MEMORY_100k_range10_ratio":summary["memory_indexes"]["statistics"][100000]["HASH_div_BTREE"]["range_10"],
 "compression_reduction":{p:v["reduction_percent"] for p,v in summary["compression"]["SST_statistics"].items()},
 "cache_lookup_ratio":summary["cache_pressure"]["lookup_ratio"],
 "write_losses":{e:summary["write_diagnostics"]["disjoint_groups"][e]["two_to_four_loss_percent"] for e in ("MyISAM","MEMORY")}},indent=2))

