"""Identify archived-source-equivalent Git revisions, not attest execution of those commits."""
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1])
def git(*args):
    return subprocess.check_output(["git","-C",str(root),*args],stderr=subprocess.DEVNULL)
cases=[
("OpenFlights","evidence/openflights/20261009T160813Z-openflights-6884f225/results.json","bf4a35ac01fde21bb998cb4b0c407b0611d46325","source_sha256"),
("Storage","evidence/storage/20261006T120404Z-storage-a5d23142/results.json","73ab5e9176dce9de7e40091a0c96e70647cb8e8a","source_sha256"),
("Recovery","evidence/recovery/20261006T161514Z-recovery-99656d7e/results.json","520c70fa70c2d0654b2c7fe1215e2b0524d5f5b1","source_sha256"),
("MEMORY index","evidence/memory-indexes/20261016T170049Z-memory-indexes-d7d3b1c7/results.json","8d2a8f4753cd306ba5bfc0791a35b7c62d84c0e3","source_sha256"),
("Compression","evidence/rocksdb-compression/20261027T220128Z-rocksdb-compression-ea876f45/results.json","cd3865136c8f466d3d19a5e327c578e033478778","source_sha256"),
]
output=[]
for label,p,sha,key in cases:
    record=json.loads((root/p).read_bytes())
    sets=[("host/top",record[key])]
    if label=="Storage":sets.append(("representative worker",record["trials"][0]["load"]["source_sha256"]))
    if label=="Recovery":sets.append(("representative writer",record["trials"][0]["acknowledgments"]["source_sha256"]))
    if label=="Compression":sets.append(("representative worker",record["trials"][0]["source_sha256"]))
    result={"label":label,"raw":p,"source_equivalent_revision":sha,"recorded_git_commit":record.get("git_commit"),
            "archive_commit":git("log","--reverse","--format=%H","HEAD","--",p).decode().splitlines()[0],"fingerprint_checks":[]}
    for scope,files in sets:
        mismatches=[]
        for name,h in files.items():
            try:b=git("show",sha+":"+name)
            except subprocess.CalledProcessError:mismatches.append(name+" absent");continue
            lf=b.replace(b"\r\n",b"\n")
            variants={hashlib.sha256(lf).hexdigest(),hashlib.sha256(lf.replace(b"\n",b"\r\n")).hexdigest()}
            if h not in variants:mismatches.append(name)
        result["fingerprint_checks"].append({"scope":scope,"files":len(files),"mismatches":mismatches})
        if mismatches:raise ValueError(result)
    output.append(result)
pathlib.Path(__file__).with_name("source-identities.json").write_text(json.dumps(output,indent=2)+"\n")
print(json.dumps(output,indent=2))

