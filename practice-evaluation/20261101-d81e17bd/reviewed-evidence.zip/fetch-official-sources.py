from pathlib import Path
import urllib.request,hashlib,json,datetime,re,html,concurrent.futures
root=Path('/workspace/cu-fresh-evaluation-20261101.9sVi1nOz/artifacts/sources')
raw=(root/'official-page.html').read_text()
prompt=html.unescape(re.search(r'<pre class="wp-block-code"><code>(Evaluate the student.*?)</code></pre>',raw,re.S).group(1))
(root/'official-evaluation-prompt-live.txt').write_text(prompt+'\n')
request=Path('/workspace/attachments/1147c9e2-8f01-4d4b-8ff5-b5ac8f8df91b/Pasted text.txt').read_text()
supplied=request.split('```text\n',1)[1].split('\n```',1)[0]
print('Prompt exact equality (excluding final whitespace):',prompt.rstrip()==supplied.rstrip())
if prompt.rstrip()!=supplied.rstrip():
 import difflib
 diff='\n'.join(difflib.unified_diff(supplied.splitlines(),prompt.splitlines(),fromfile='supplied',tofile='live'))
 (root/'prompt-diff.patch').write_text(diff+'\n');print(diff)
area_html=raw.split('<h3 class="wp-block-heading" id="6-choosing-the-right-storage-engine">',1)[1].split('<h3',1)[0]
area=html.unescape(re.sub('<[^>]+>','',area_html));area='\n'.join(x.strip().replace('\xa0',' ') for x in area.splitlines() if x.strip())
(root/'official-area-6-live.txt').write_text(area+'\n')
urls={
'storage-engines':'https://mariadb.com/docs/server/server-usage/storage-engines.md',
'innodb-introduction':'https://mariadb.com/docs/server/server-usage/storage-engines/innodb/innodb-storage-engine-introduction.md',
'aria':'https://mariadb.com/docs/server/server-usage/storage-engines/aria/aria-storage-engine.md',
'myisam':'https://mariadb.com/docs/server/server-usage/storage-engines/myisam-storage-engine/myisam-overview.md',
'memory':'https://mariadb.com/docs/server/server-usage/storage-engines/memory-storage-engine.md',
'myrocks-architecture':'https://mariadb.com/docs/server/server-usage/storage-engines/myrocks/about-myrocks-for-mariadb.md',
'myrocks-isolation':'https://mariadb.com/docs/server/server-usage/storage-engines/myrocks/myrocks-transactional-isolation.md',
'innodb-lock-modes':'https://mariadb.com/docs/server/server-usage/storage-engines/innodb/innodb-lock-modes.md',
'foreign-keys':'https://mariadb.com/docs/server/ha-and-performance/optimization-and-tuning/optimization-and-indexes/foreign-keys.md',
}
def fetch(item):
 name,url=item
 try:
  with urllib.request.urlopen(url,timeout=60) as r:
   b=r.read();meta={'url':url,'final_url':r.url,'retrieved_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'http_status':r.status,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'file':name+'.md'}
  (root/(name+'.md')).write_bytes(b)
 except Exception as e:meta={'url':url,'retrieved_at_utc':datetime.datetime.now(datetime.UTC).isoformat(),'error':str(e)}
 print(name,meta.get('http_status'),meta.get('bytes'),meta.get('error',''),flush=True)
 return meta
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex: records=list(ex.map(fetch,urls.items()))
(root/'reference-retrievals.json').write_text(json.dumps(records,indent=2)+'\n')
