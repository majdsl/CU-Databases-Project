# Official source verification

This is source/rubric verification for the fresh AI practice evaluation, not an assessment score. No previous assessment scores or conclusions were consulted.

## Version and identity

- The live assignment returned HTTP 200 on 2026-11-01 at 17:31:49 UTC (18:31:49 Europe/Berlin); page HTML SHA-256 is `def175cc1457216f948483c141d0ec7e023cd0b4a3f67c537a73c74293bdb99f`.
- The page states **Last updated 2026-09-04** for its evaluation prompt.
- Decoding the `wp-block-code` block yielded the same prompt as the user-supplied verbatim text, exactly after trimming trailing whitespace. There are **no rubric or required-output differences**. The decoded live text is `sources/official-evaluation-prompt-live.txt`.
- The current live Area 6 matches the supplied Area 6 wording and linked reference. The normalized live section is `sources/official-area-6-live.txt`.
- The checked checkout's README first line names **area 6, "Choosing the right storage engine"**, includes the assignment link and follows the required first-line form. This was confirmed directly in `repo/README.md`, rather than inferred from the task.

## Capability surface and project reach

The linked Storage Engines entry point is an index. Its overview explains per-table engine choice, `SHOW ENGINES`, default storage engines and engine identification through INFORMATION_SCHEMA; its selection guide distinguishes transactional general use, disposable caches, compression and specialized engines. Neither the area description nor rubric requires implementing every engine in that index. Area 6 specifically requires the same schema/workload across at least three engines, repeat measurements with stated machines/settings, actionable trade-offs and a reusable harness.

The following distinctions were read in the live reference pages and compared to current source/docs:

| Reference capability | Found in project source/docs | Boundary |
| --- | --- | --- |
| Per-table engines and actual engine identity | `sql/openflights/{innodb,aria,myisam,memory,rocksdb}.sql` explicitly choose five engines; all retain the same columns and BTREE primary/secondary indexes. `sql/tutorial/05b-transactions.sql` and `05c-myrocks-transactions.sql` query actual `information_schema.TABLES.ENGINE`. | This source inspection is not fresh SQL execution. |
| InnoDB transactions/row locking, default recommendation for authoritative OLTP data | `sql/tutorial/05b-transactions.sql` performs the two-row transfer, ROLLBACK and COMMIT; `docs/tutorial.md` includes separate concurrent-writer cases/counters; `docs/engine-recommendations.md` starts authoritative transactional applications at InnoDB. | Foreign keys, deadlocks, interrupted transactions and isolation failure modes remain documented features/inferences rather than demonstrated application behavior. |
| Aria PAGE crash safety and `TRANSACTIONAL` option do not provide multi-statement application transactions | `docs/tutorial.md`, `docs/engine-recommendations.md` and the Aria transaction SQL make the distinction explicitly and expect retained writes after ROLLBACK. | Recovery under process restarts does not establish device/power-loss behavior. The reference's opening summary uses broad "transactional capabilities" wording, but its detailed table-option description explicitly denies application transaction support; the project follows the detailed distinction. |
| MyISAM separate data/index files, no transactions/foreign keys, table rather than row locks; Aria preferred for new applications | `docs/engine-recommendations.md` makes its MyISAM recommendation narrowly conditional on disposable load-heavy data and acknowledges forced-restart warnings and Aria guidance. | Observed survival does not prove transactional safety. |
| MEMORY volatility, RAM capacity, default HASH and optional BTREE | `sql/openflights/memory.sql` explicitly uses BTREE to keep shared schema comparable; `docs/tutorial.md` shows HASH range fallback and restart row loss; `docs/memory-index-findings.md` adds measurement. | Exhausting RAM/repopulating a production cache and replication implications are outside the project experiments. |
| MyRocks LSM design, compression, column families and compaction | `benchmarks/rocksdb_compression.py` selects `kNoCompression` versus `kZSTD` and explicitly disables automatic compaction. `docs/rocksdb-compression-method.md` calls its study flush-only; recommendations condition sustained-write/space claims on further trials. | The project does not establish steady-state compaction cost, sustained bulk ingestion or general IO/CPU advantage. |
| MyRocks supports READ COMMITTED and REPEATABLE READ, excludes SERIALIZABLE and gap locking | `docs/engine-recommendations.md` states those compatibility restrictions; `sql/tutorial/05c-myrocks-transactions.sql` demonstrates ordinary COMMIT/ROLLBACK. | Isolation compatibility is sourced reference knowledge, not a new measured result. |

I directly read `README.md` first line, the factual handoff, `docs/engine-recommendations.md`, relevant portions of `docs/tutorial.md`, all OpenFlights engine-DDL declarations and both transaction SQL files. Other reviewing agents investigate the raw measurements and actual execution. These sources support that the implemented scope reaches beyond switching the ENGINE clause: failure/restart behavior, index access types, locking, buffer-pool pressure and compression are deliberately investigated. The reference is broader than the chosen experiment; absence of every available specialized engine is not an automatic rubric deduction.

## Retrieval record

All eleven requested MariaDB Markdown references returned HTTP 200. No required official material was unavailable. TLS verification and the inherited session proxy were preserved. Raw fetched bytes and the retrieval JSON are kept beside this note. `artifacts/fetch-official-sources.py` preserves the extraction and principal reference-fetch procedure; two additional overview/selection fetches used the same urllib/hash/date procedure and were appended to `reference-retrievals.json`.

| Source | Retrieved UTC | HTTP | SHA-256 |
| --- | --- | --- | --- |
| https://mariadb.org/bachelor_hackathon_2026-09/ | 2026-11-01T17:31:49.319265+00:00 | 200 | `def175cc1457216f948483c141d0ec7e023cd0b4a3f67c537a73c74293bdb99f` |
| https://mariadb.com/docs/server/server-usage/storage-engines.md | 2026-11-01T17:32:17.536713+00:00 | 200 | `15fb95ec8e14337e24e650f0179d990fd4e1a55ed03e1af856a21ff61bb5df61` |
| https://mariadb.com/docs/server/server-usage/storage-engines/innodb/innodb-storage-engine-introduction.md | 2026-11-01T17:32:17.575103+00:00 | 200 | `b0860d396db31fd97e5c8c6121d056a7bd1472b4b2a22f105b7570492eafd1cd` |
| https://mariadb.com/docs/server/server-usage/storage-engines/aria/aria-storage-engine.md | 2026-11-01T17:32:17.628203+00:00 | 200 | `f59a8ceb8212fb90a54580c55df3ff0378aca0337386b0d2e4777491279f7a8c` |
| https://mariadb.com/docs/server/server-usage/storage-engines/myisam-storage-engine/myisam-overview.md | 2026-11-01T17:32:17.599358+00:00 | 200 | `b35e70ec5513d68621f6329b3a67076b44e0fde5a3b6d78fa15c5130c978a707` |
| https://mariadb.com/docs/server/server-usage/storage-engines/memory-storage-engine.md | 2026-11-01T17:32:17.885696+00:00 | 200 | `7986085b0bc3d403a32ba7baf7c699d8d1744d5087fec747f4fa46bdabd5d575` |
| https://mariadb.com/docs/server/server-usage/storage-engines/myrocks/about-myrocks-for-mariadb.md | 2026-11-01T17:32:17.997221+00:00 | 200 | `4df0bdeac75a65f3e2d445ac6ae346ec9b95d79202f89807e8cba667295b1922` |
| https://mariadb.com/docs/server/server-usage/storage-engines/myrocks/myrocks-transactional-isolation.md | 2026-11-01T17:32:17.993578+00:00 | 200 | `f1948d205f0a18720bd0ec678a10f3477c55a27b87ce1dc7028eb147ffc8c514` |
| https://mariadb.com/docs/server/server-usage/storage-engines/innodb/innodb-lock-modes.md | 2026-11-01T17:32:18.124874+00:00 | 200 | `070dfb32b764f4fc1755a360fd61b82337b3bf76bbc4b08cbd3528c023e84279` |
| https://mariadb.com/docs/server/ha-and-performance/optimization-and-tuning/optimization-and-indexes/foreign-keys.md | 2026-11-01T17:32:18.382046+00:00 | 200 | `e524ff4a7a595569011edf100bda4d3ff718fa15af541c83afc9a87a984b5616` |
| https://mariadb.com/docs/server/server-usage/storage-engines/storage-engines-storage-engines-overview.md | 2026-11-01T17:32:37.049496+00:00 | 200 | `6bf3e203798cc1c39b993338cb12a49c36150ca425a013013b5de2de2566d0b0` |
| https://mariadb.com/docs/server/server-usage/storage-engines/choosing-the-right-storage-engine.md | 2026-11-01T17:32:37.341869+00:00 | 200 | `ab1c3361b9bfc790aa86b66d4b0013d712a1c0772b346f7ee6fd2b7c87b7590b` |
