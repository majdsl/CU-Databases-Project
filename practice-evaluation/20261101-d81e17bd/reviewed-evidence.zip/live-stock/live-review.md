# Fresh four-engine SQL check

Frozen assessed checkout HEAD: `d81e17bd92b67d29905a59ff1af2a22745f0187d`.

Executed once on 2026-11-01 at 17:33:31 UTC (18:33:31 Europe/Berlin):

```text
python3 /workspace/cu-fresh-evaluation-20261101.9sVi1nOz/run_logged.py --cwd /workspace/cu-fresh-evaluation-20261101.9sVi1nOz/repo --label fresh-stock-tutorial -- python3 scripts/check_stock_tutorial.py --output /workspace/cu-fresh-evaluation-20261101.9sVi1nOz/artifacts/live-stock --expect-architecture amd64
```

The process exited **0** after **132.804 seconds**, ending `STOCK TUTORIAL PASS: amd64`. No GitHub CI identity or variables were faked. The driver's `commit` field is consequently null, as documented for manual invocation; the independently recorded HEAD and all four driver/workflow source hashes plus all seven mounted SQL-file hashes were checked against the frozen checkout. See `independent-postcheck.json` and capacity's `post-source-head.txt`.

## Actual observations

- Native Linux amd64 host, Docker daemon and pinned image agreed. Server reported `11.8.9-MariaDB-ubu2404`, image ID `sha256:cc7f5fdd7c8fff6867e8ac4df3e7e0faf6c56aebe621a13565479a9a94e4bf13`, selected through pinned repository digest `sha256:8b5f33ebd85d1775657e974ed10434128bb493c80e826ceaa54074fd1a92a112`.
- Disposable project `cu-stock-4f48c97054b9` passed collision checks, ran with no network or published port under 2 CPU/1 GiB caps, and used a fresh named volume. It did not use the preexisting lab volume.
- Real InnoDB, Aria, MyISAM and MEMORY identities were checked with 50,000 deterministic rows per table, including IDs, generated fields, notes and aggregate checks. No MyRocks table was used on this documented four-engine path.
- MEMORY BTREE and HASH examples each contained 100,000 rows. Equality returned 20 rows with `ref`; a 200-row range used BTREE `range` and HASH `ALL`.
- Six malformed procedure inputs were rejected with SQLSTATE `45000`, without changing rows. These are the only six nonzero internal command exits: **152 recorded Docker command invocations, 146 exit 0 and six deliberately expected exit 1**. All records and failure text remain in `commands.json` and `transcript.txt`.
- Single-writer totals and four two-writer cases (Aria/InnoDB, disjoint/same row) matched affected-row counts. SQL server intervals showed some overlap in each case; same-row InnoDB overlap was only 0.000988 seconds and its global row-lock wait count did not rise. The driver appropriately imposes no minimum lock-counter or overlap threshold and these observations do not establish a contention ranking.
- The transaction example restored InnoDB's two-row balance after rollback; Aria, MyISAM and MEMORY retained the transfer, with exact before/during/after balances verified. Commit outcomes also matched.
- A guarded clean restart preserved persistent engines' rows and updates; MEMORY emptied. Tutorial cleanup removed its tables/procedure while preserving the unrelated sentinel.

## Independent post-check and scope

After the driver checked ownership and removed its own disposable container and volume, separate Docker queries found no containers, the original `cu-engine-lab_db_data` volume still present, and all three original image IDs present. The owned stock volume was absent. Git HEAD still matched the frozen SHA and `git status --porcelain` remained empty. Physical free space on the shared checkout/Docker filesystem was 7,545,118,720 bytes (about 7.03 GiB), with 516,755 free inodes; evaluation artifacts were being created concurrently, so the change is not attributed solely to this run.

This is a fresh supported four-engine SQL correctness run of the assessed source, not the custom MyRocks build, the five-engine setup wrapper, an ARM64 execution, Windows/macOS installation or performance replication. Other evaluation processes shared this cloud environment. The one-second writer observations are used only for correctness, not as controlled benchmark measurements. No submitted files were changed, no preexisting resources were deleted, and no system pruning was performed.
