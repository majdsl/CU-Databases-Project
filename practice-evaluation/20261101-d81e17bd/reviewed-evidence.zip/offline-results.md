# Fresh offline verification

Assessed checkout: `d81e17bd92b67d29905a59ff1af2a22745f0187d`, detached from remote `main`; verification performed 2026-11-01 UTC. The dedicated virtual environment and all evaluation logs are outside the submitted source tree.

All requested offline commands completed successfully. The lightweight suite ran **146 tests** in normal Python and **146 tests** under `-O`. The report/tutorial/archive suite ran **105 tests** normally and **105 tests** under `-O`. None were skipped or failed. These are actual counts from this execution.

| Check | Exit | Observed result | Log |
| --- | ---: | --- | --- |
| `pip install --require-hashes -r requirements.txt` | 0 | PyMySQL 1.1.2 installed with required hash | `logs/offline-install-benchmark.log` |
| `pip install -r requirements-report.txt` | 0 | Matplotlib 3.10.8 and transitive dependencies installed | `logs/offline-install-report.log` |
| `scripts/fetch_openflights.py` | 0 | Downloaded and verified pinned `routes.dat` | `logs/offline-fetch-openflights.log` |
| `-m unittest discover -s tests -v` | 0 | 146 tests; OK | `logs/offline-tests.log` |
| `-O -m unittest discover -s tests -v` | 0 | 146 tests; OK | `logs/offline-tests-optimized.log` |
| `-m unittest discover -s report-tests -v` | 0 | 105 tests; OK | `logs/offline-report-tests.log` |
| `-O -m unittest discover -s report-tests -v` | 0 | 105 tests; OK | `logs/offline-report-tests-optimized.log` |
| `scripts/check_reports.py --repeat` | 0 | 8 reports, 55 outputs; inputs preserved; optimization=0 | `logs/offline-check-reports-repeat.log` |
| `scripts/check_cloud_openflights.py` | 0 | 60 validated trials, 50 full trials compared, 59 checksum files | `logs/offline-check-cloud.log` |
| `-O scripts/check_cloud_openflights.py` | 0 | Same successful offline validation | `logs/offline-check-cloud-optimized.log` |
| `evidence/reproductions/20261101-ci-openflights-session/verify.py` | 0 | 34 files checked | `logs/offline-ci-session-verify.log` |
| `evidence/reproductions/20261101-ci-openflights-session/bundle/verify.py` | 0 | 14 files checked | `logs/offline-ci-bundle-verify.log` |
| `evidence/reproductions/20261101-ci-openflights-session/recheck.py` | 0 | 5 pilot/25 full trials, statistics, controls, images, clean stop, 15 original export entries | `logs/offline-ci-session-recheck.log` |
| `-O evidence/reproductions/20261101-ci-openflights-session/recheck.py` | 0 | Same successful semantic recheck | `logs/offline-ci-session-recheck-optimized.log` |
| `evidence/reviews/20261101-snapshot-builds/verify.py` | 0 | 80 files checked | `logs/offline-snapshot-builds-verify.log` |
| `evidence/reviews/20261101-local-validation/verify.py` | 0 | 24 files checked | `logs/offline-local-validation-verify.log` |
| `evidence/reviews/20261031-build-evidence/verify.py` | 0 | 45 files checked | `logs/offline-build-evidence-verify.log` |
| `evidence/reviews/20261031-final-guards/verify.py` | 0 | 6 files checked | `logs/offline-final-guards-verify.log` |

The external `run_logged.py` wrapper records exact argv, working directory, timestamp, duration, exit code and stdout/stderr for each command. `commands.jsonl` is the machine-readable command index. Independent offline checks ran with up to three subprocesses concurrently. These durations are verification runtimes, not benchmark results. The two report suites each exercise repeated regeneration internally, as required by their existing tests; the separate documented `--repeat` check also ran once. No passing command was rerun in response to a desired result.

Python was **3.12.14**, the repository's tested reporting minor version. Git was **2.52.0**, OpenSSL **3.5.7**. `logs/offline-installed-versions.log` preserves the complete installed package list; `logs/offline-env.log` and `logs/offline-tool-versions.log` preserve platform/version output. No TLS, signature or hash verification was disabled.

Representative test source was also inspected (`logs/offline-test-source-samples.log`). `tests/test_baseline.py` uses known-answer statistics and checks row corruption, balanced schedules, equal round weighting, engine substitution and comparable schemas. `report-tests/test_report_regeneration.py` tests generation from current source, source preservation and malformed/mutated input rejection. Expected mocked failure-path messages appear within successful tests; they are not failed live database runs.

The report checker regenerates current reports from archived measurements in disposable copies, compares narrative/CSV/JSON, validates image formats and repeated-generation stability, and verifies input preservation. Archive checks establish byte integrity and, where applicable, semantic consistency of recorded statistics/controls. They do not independently authenticate the historical producer or execute SQL. No Docker or SQL workload was launched by these offline commands.

At completion, every tracked working-tree file was compared byte for byte with its Git-index blob, with zero mismatches; both staged and unstaged diffs were empty and `git status --porcelain` was empty (`logs/offline-tracked-integrity-final.log`). `tracked-working-tree-sha256.json` records the working-byte digest of each tracked file. The only fetched project input was the ignored, checksum-pinned OpenFlights data file. No submitted source or historical evidence was repaired or edited.
