> For the complete documentation index, see [llms.txt](https://mariadb.com/docs/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://mariadb.com/docs/server/server-usage/storage-engines/storage-engines-storage-engines-overview.md).

# Storage Engines Overview

An introduction to MariaDB's pluggable storage engine architecture, highlighting key engines like InnoDB, MyISAM, and Aria for different workloads.

## Overview

MariaDB features pluggable storage engines to allow per-table workload optimization.

A storage engine is a type of [plugin](/docs/server/reference/plugins.md) for MariaDB:

* Different storage engines may be optimized for different workloads, such as transactional workloads, analytical workloads, or high throughput workloads.
* Different storage engines may be designed for different use cases, such as federated table access, table sharding, and table archiving in the cloud.
* Different tables on the same server may use different storage engines.

| Engine                                                                       | Target          | Optimization         | Availability |
| ---------------------------------------------------------------------------- | --------------- | -------------------- | ------------ |
| [Aria](/docs/server/server-usage/storage-engines/aria.md)                    | Read-Heavy      | Reads                | ES           |
| [ColumnStore](/docs/release-notes/columnstore.md)                            | Analytics, HTAP | Big Data, Analytical | ES           |
| [InnoDB](/docs/server/server-usage/storage-engines/innodb.md)                | General Purpose | Mixed Read/Write     | ES           |
| [Memory](/docs/server/server-usage/storage-engines/memory-storage-engine.md) | Cache, Temp     | Temporary Data       | ES           |
| [MyISAM](/docs/server/server-usage/storage-engines/myisam-storage-engine.md) | Reads           | Reads                | ES           |
| [MyRocks](/docs/server/server-usage/storage-engines/myrocks.md)              | Write-Heavy     | I/O Reduction, SSD   | ES           |
| [S3](/docs/server/server-usage/storage-engines/s3-storage-engine.md)         | Cloud           | Read-Only            | ES           |
| [Spider](/docs/server/server-usage/storage-engines/spider.md)                | Federation      | Sharding, Interlink  | ES           |

## Examples

### Identify the Default Storage Engine

Identify the server's global default storage engine by using [SHOW GLOBAL VARIABLES](/docs/server/reference/sql-statements/administrative-sql-statements/show/show-variables.md) to query the [default\_storage\_engine](/docs/server/server-management/variables-and-modes/server-system-variables.md#default_storage_engine) system variable:

```sql
SHOW GLOBAL VARIABLES LIKE 'default_storage_engine';
```

```sql
+------------------------+--------+
| Variable_name          | Value  |
+------------------------+--------+
| default_storage_engine | InnoDB |
+------------------------+--------+
```

Identify the session's default storage engine by using [SHOW SESSION VARIABLES](/docs/server/reference/sql-statements/administrative-sql-statements/show/show-variables.md):

```
SHOW SESSION VARIABLES LIKE 'default_storage_engine';
```

```sql
+------------------------+--------+
| Variable_name          | Value  |
+------------------------+--------+
| default_storage_engine | InnoDB |
+------------------------+--------+
```

### Set the Default Storage Engine

Global default storage engine:

```sql
SET GLOBAL default_storage_engine='MyRocks';
```

Session default storage engine supersedes global default during this session:

```sql
SET SESSION default_storage_engine='MyRocks';
```

### Configure the Default Storage Engine

```bash
[mariadb]
...
default_storage_engine=MyRocks
```

### Identify Available Storage Engines

```sql
SHOW ENGINES;
```

### Choose Storage Engine for a New Table

Storage engine is specified at time of table creation using a ENGINE = parameter.

```sql
CREATE TABLE accounts.messages (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sender_id INT,
  receiver_id INT,
  message TEXT
) ENGINE = MyRocks;
```

## Resources

### Engines for System Tables

Standard MariaDB storage engines are used for System Table storage:

* [Aria Storage Engine](/docs/server/server-usage/storage-engines/aria.md)
* [MyISAM Storage Engine](/docs/server/server-usage/storage-engines/myisam-storage-engine.md)

## FAQ

### Can I use more than one storage engine on a server?

* Yes, different tables can use different storage engines on the same server.
* To create a table with a specific storage engine, specify the ENGINE table option to the [CREATE TABLE](/docs/server/server-usage/tables/create-table.md) statement.

### Can I use more than one storage engine in a single query?

* Yes, a single query can reference tables that use multiple storage engines.
* In some cases, special configuration may be required. For example, ColumnStore requires cross engine joins to be configured.

### What storage engine should I use for transactional or OLTP workloads?

* [InnoDB](/docs/server/server-usage/storage-engines/innodb.md) is the recommended storage engine for transactional or OLTP workloads.

### What storage engine should I use for analytical or OLAP workloads?

* [ColumnStore](/docs/release-notes/columnstore.md) is the recommended storage engine for analytical or OLAP workloads.

### What storage engine should I use if my application performs both transactional and analytical queries?

An application that performs both transactional and analytical queries is known as [hybrid transactional-analytical processing (HTAP)](/docs/server/architecture/topologies/htap.md).

HTAP can be implemented with MariaDB by using [InnoDB](/docs/server/server-usage/storage-engines/innodb.md) for transactional queries and [ColumnStore](/docs/release-notes/columnstore.md) for analytical queries.

## Reference

### MariaDB Server Reference

* [Plugins](/docs/server/reference/plugins.md).
* [Information Schema ENGINES table](/docs/server/reference/system-tables/information-schema/information-schema-tables/information-schema-engines-table.md), which shows available storage engines.
* [Information Schema TABLES table](/docs/server/reference/system-tables/information-schema/information-schema-tables/information-schema-tables-table.md), which shows storage engine by table.

<sub>*This page is: Copyright © 2026 MariaDB. All rights reserved.*</sub>

{% @marketo/form formId="4316" %}
