> For the complete documentation index, see [llms.txt](https://mariadb.com/docs/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://mariadb.com/docs/server/server-usage/storage-engines/choosing-the-right-storage-engine.md).

# Choosing the Right Storage Engine

A guide to selecting the appropriate storage engine based on data needs, comparing features of general-purpose, columnar, and specialized engines.

A high-level overview of the main reasons for choosing a particular storage engine:

{% hint style="info" %}
CONNECT, Mroonga, MyRocks, OQGRAPH, SphinxSE, and VIDEX are community contributions, developed and maintained by their respective contributors. Each of those engines' pages says who maintains it.
{% endhint %}

## Topic List

### General Purpose

* [InnoDB](/docs/server/server-usage/storage-engines/innodb.md) is a good general transaction storage engine, and the best choice in most cases. It is the default storage engine.
* [Aria](/docs/server/server-usage/storage-engines/aria.md), MariaDB's more modern improvement on [MyISAM](/docs/server/server-usage/storage-engines/myisam-storage-engine.md), has a small footprint and allows for easy copying between systems.
* [MyISAM](/docs/server/server-usage/storage-engines/myisam-storage-engine.md) has a small footprint and allows for easy copying between systems. MyISAM is MySQL's oldest storage engine. There is usually little reason to use it except for legacy purposes. Aria is MariaDB's more modern improvement.
* [XtraDB](/docs/server/server-usage/storage-engines/innodb.md) is no longer available. It was a performance-enhanced fork of InnoDB.

### Scaling, Partitioning

When you want to split your database load on several servers or optimize for scaling. We also suggest looking at [Galera](/docs/galera-cluster/readme/mariadb-galera-cluster-usage-guide.md), a synchronous multi-master cluster.

* [Spider](/docs/server/server-usage/storage-engines/spider.md) uses partitioning to provide data sharding through multiple servers.
* [ColumnStore](/docs/release-notes/columnstore.md) utilizes a massively parallel distributed data architecture and is designed for big data scaling to process petabytes of data.
* The [MERGE](/docs/server/server-usage/storage-engines/merge.md) storage engine is a collection of identical [MyISAM](/docs/server/server-usage/storage-engines/myisam-storage-engine.md) tables that can be used as one. "Identical" means that all tables have identical column and index information.

### Compression / Archive

* [MyRocks](/docs/server/server-usage/storage-engines/myrocks.md) enables greater compression than InnoDB, as well as less write amplification giving better endurance of flash storage and improving overall throughput.
* The [Archive](/docs/server/server-usage/storage-engines/archive.md) storage engine is, unsurprisingly, best used for archiving.

### Connecting to Other Data Sources

When you want to use data not stored in a MariaDB database.

* The [CSV](/docs/server/server-usage/storage-engines/csv.md) storage engine can read and append to files stored in CSV (comma-separated-values) format. However, CONNECT is a better choice and is more flexibly able to read and write such files.

### Search Optimized

Search engines optimized for search.

* [SphinxSE](/docs/server/server-usage/storage-engines/sphinx-storage-engine.md) is used as a proxy to run statements on a remote Sphinx database server (mainly useful for advanced fulltext searches).
* [Mroonga](/docs/server/server-usage/storage-engines/mroonga.md) provides fast CJK-ready full text searching using column store.

### Cache, Read-only

* [MEMORY](/docs/server/server-usage/storage-engines/memory-storage-engine.md) does not write data on-disk (all rows are lost on crash) and is best-used for read-only caches of data from other tables, or for temporary work areas. With the default [InnoDB](/docs/server/server-usage/storage-engines/innodb.md) and other storage engines having good caching, there is less need for this engine than in the past.

### Other Specialized Storage Engines

* [S3 Storage Engine](/docs/server/server-usage/storage-engines/s3-storage-engine.md) is a read-only storage engine that stores its data in Amazon S3.
* [Sequence](/docs/server/server-usage/storage-engines/sequence-storage-engine.md) allows the creation of ascending or descending sequences of numbers (positive integers) with a given starting value, ending value and increment, creating virtual, ephemeral tables automatically when you need them.
* The [BLACKHOLE](/docs/server/server-usage/storage-engines/blackhole.md) storage engine accepts data but does not store it and always returns an empty result. This can be useful in [replication](/docs/server/ha-and-performance/standard-replication/replication-overview.md) environments, for example, if you want to run complex filtering rules on a slave without incurring any overhead on a master.
* [OQGRAPH](/docs/server/server-usage/storage-engines/oqgraph-storage-engine.md) allows you to handle hierarchies (tree structures) and complex graphs (nodes having many connections in several directions).
* The [VIDEX](/docs/server/server-usage/storage-engines/videx-storage-engine.md) storage engine is an aggregated, extensible engine suitable for what-if analyses in MariaDB. The name is derived from \[VI]rtual in\[DEX]. Using VIDEX, you can evaluate how potential indexes (and optimizer decisions such as join orders) would change query plans *without creating real indexes on production data*.

## Alphabetical List

* The [Archive](/docs/server/server-usage/storage-engines/archive.md) storage engine is, unsurprisingly, best used for archiving.
* [Aria](/docs/server/server-usage/storage-engines/aria.md), MariaDB's more modern improvement on MyISAM, has a small footprint and allows for easy copy between systems.
* The [BLACKHOLE](/docs/server/server-usage/storage-engines/blackhole.md) storage engine accepts data but does not store it and always returns an empty result. This can be useful in [replication](/docs/server/ha-and-performance/standard-replication/replication-overview.md) environments, for example, if you want to run complex filtering rules on a slave without incurring any overhead on a master.
* [ColumnStore](/docs/release-notes/columnstore.md) utilizes a massively parallel distributed data architecture and is designed for big data scaling to process petabytes of data.
* [CONNECT](/docs/server/server-usage/storage-engines/connect.md) allows access to different kinds of text files and remote resources as if they were regular MariaDB tables.
* The [CSV](/docs/server/server-usage/storage-engines/csv/csv-overview.md) storage engine can read and append to files stored in CSV (comma-separated-values) format. However, CONNECT is a better choice and is more flexibly able to read and write such files.
* [InnoDB](/docs/server/server-usage/storage-engines/innodb.md) is a good general transaction storage engine, and the best choice in most cases. It is the default storage engine.
* The [MERGE](/docs/server/server-usage/storage-engines/merge.md) storage engine is a collection of identical MyISAM tables that can be used as one. "Identical" means that all tables have identical column and index information.
* [MEMORY](/docs/server/server-usage/storage-engines/memory-storage-engine.md) does not write data on-disk (all rows are lost on crash) and is best-used for read-only caches of data from other tables, or for temporary work areas. With the default [InnoDB](/docs/server/server-usage/storage-engines/innodb.md) and other storage engines having good caching, there is less need for this engine than in the past.
* [Mroonga](/docs/server/server-usage/storage-engines/mroonga.md) provides fast CJK-ready full text searching using column store.
* [MyISAM](/docs/server/server-usage/storage-engines/myisam-storage-engine.md) has a small footprint and allows for easy copying between systems. MyISAM is MySQL's oldest storage engine. There is usually little reason to use it except for legacy purposes. Aria is MariaDB's more modern improvement.
* [MyRocks](/docs/server/server-usage/storage-engines/myrocks.md) enables greater compression than InnoDB, as well as less write amplification giving better endurance of flash storage and improving overall throughput.
* [OQGRAPH](/docs/server/server-usage/storage-engines/oqgraph-storage-engine.md) allows you to handle hierarchies (tree structures) and complex graphs (nodes having many connections in several directions).
* [S3 Storage Engine](/docs/server/server-usage/storage-engines/s3-storage-engine.md) is a read-only storage engine that stores its data in Amazon S3.
* [Sequence](/docs/server/server-usage/storage-engines/sequence-storage-engine.md) allows the creation of ascending or descending sequences of numbers (positive integers) with a given starting value, ending value and increment, creating virtual, ephemeral tables automatically when you need them.
* [SphinxSE](/docs/server/server-usage/storage-engines/sphinx-storage-engine.md) is used as a proxy to run statements on a remote Sphinx database server (mainly useful for advanced fulltext searches).
* [Spider](/docs/server/server-usage/storage-engines/spider.md) uses partitioning to provide data sharding through multiple servers.
* The [VIDEX](/docs/server/server-usage/storage-engines/videx-storage-engine.md) storage engine is an aggregated, extensible engine suitable for what-if analyses in MariaDB.

<sub>*This page is licensed: CC BY-SA / Gnu FDL*</sub>

{% @marketo/form formId="4316" %}
