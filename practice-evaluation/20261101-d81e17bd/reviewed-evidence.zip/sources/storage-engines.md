> For the complete documentation index, see [llms.txt](https://mariadb.com/docs/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://mariadb.com/docs/server/server-usage/storage-engines.md).

# Storage Engines

Understand MariaDB Server's storage engines. Explore the features and use cases of InnoDB, Aria, MyISAM, and other engines to choose the best option for your specific data needs.

{% columns %}
{% column %}
{% content-ref url="/pages/vozHilHZ7RvjvnBazO5P" %}
[Storage Engines Overview](/docs/server/server-usage/storage-engines/storage-engines-storage-engines-overview.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
An introduction to MariaDB's pluggable storage engine architecture, highlighting key engines like InnoDB, MyISAM, and Aria for different workloads.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/2Sx6Ccw2hJXMWLRa0DoK" %}
[Choosing the Right Storage Engine](/docs/server/server-usage/storage-engines/choosing-the-right-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
A guide to selecting the appropriate storage engine based on data needs, comparing features of general-purpose, columnar, and specialized engines.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/VLw8sXFo2eiTxRQHjqya" %}
[ARCHIVE](/docs/server/server-usage/storage-engines/archive.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The Archive storage engine is optimized for high-speed insertion and compression of large amounts of data, suitable for logging and auditing.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/ZFcEwb6C2EzZNZqtO978" %}
[ARIA](/docs/server/server-usage/storage-engines/aria.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Learn about the Aria storage engine in MariaDB Server. Understand its features, advantages, and use cases, particularly for crash-safe operations and transactional workloads.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/7pkUhI0V6bLIZbTNbFJH" %}
[BLACKHOLE](/docs/server/server-usage/storage-engines/blackhole.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The BLACKHOLE storage engine discards all data written to it but records operations in the binary log, useful for replication filtering and testing.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/Hwi7qeVac1t95WRhp1AK" %}
[CONNECT](/docs/server/server-usage/storage-engines/connect.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The main characteristic of CONNECT is to enable accessing data scattered on a machine as if it was a centralized database.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/GFFki3kVnQvOVmRnU3en" %}
[CSV](/docs/server/server-usage/storage-engines/csv.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The CSV storage engine stores data in text files using comma-separated values format, allowing easy data exchange with other applications.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/exQUl2c2HoqXmBFCNhvt" %}
[DuckDB](/docs/server/server-usage/storage-engines/duckdb-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
DuckDB embedded as a MariaDB storage engine for analytical workloads. Experimental, at alpha maturity, and not built into MariaDB releases.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/OMlHv9HJHAHdT8bOVpGt" %}
[FederatedX](/docs/server/server-usage/storage-engines/federatedx-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
FederatedX is a storage engine that allows access to tables on remote MariaDB or MySQL servers as if they were local tables.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/7L0FHo7ZIDNGte5DosWH" %}
[InnoDB](/docs/server/server-usage/storage-engines/innodb.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Discover InnoDB, the default storage engine for MariaDB Server. Learn about its transaction-safe capabilities, foreign key support, and high performance for demanding workloads.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/WMo8gdjyeMO16IGn0eSX" %}
[MEMORY](/docs/server/server-usage/storage-engines/memory-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The MEMORY storage engine stores tables in RAM for fast access, but data is lost upon server restart.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/bcB42l4n4fGigdsYl4ft" %}
[MERGE](/docs/server/server-usage/storage-engines/merge.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The MERGE storage engine allows a collection of identical MyISAM tables to be treated as a single logical table, useful for managing large datasets.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/EuUYmSkpUZI9foPKihCt" %}
[Mroonga](/docs/server/server-usage/storage-engines/mroonga.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Mroonga (formerly named Groonga Storage Engine) is a storage engine that provides fast CJK-ready full text searching using column store.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/1xszq9BFI1rJoKIXnPVQ" %}
[MyISAM](/docs/server/server-usage/storage-engines/myisam-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Explore the MyISAM storage engine in MariaDB Server. Understand its characteristics, including suitability for read-heavy workloads, and its role in specific use cases.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/g54AP1seo1CaaCP30VtT" %}
[MyRocks](/docs/server/server-usage/storage-engines/myrocks.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Learn about the MyRocks storage engine in MariaDB Server. Discover its advantages for flash storage, high write throughput, and compression efficiency in modern database deployments.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/MsUCdugJ9DGOTGluir7x" %}
[OQGRAPH](/docs/server/server-usage/storage-engines/oqgraph-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Explore the OQGRAPH storage engine in MariaDB Server. Learn how to efficiently manage hierarchical and complex graph data structures, perfect for social networks and bill of materials.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/sakCeSkygAq1kxonl3x9" %}
[PERFORMANCE\_SCHEMA](/docs/server/server-usage/storage-engines/performance_schema-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
While technically a storage engine, PERFORMANCE\_SCHEMA provides a way to inspect internal server execution details at a low level.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/8tA1HrTu3Fpj0ELcYYNe" %}
[SEQUENCE Storage Engine](/docs/server/server-usage/storage-engines/sequence-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The Sequence engine generates virtual tables of number sequences on the fly, useful for generating series of integers without storing data.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/EZb2PU7D6KNRmXeoheeM" %}
[S3 Storage Engine](/docs/server/server-usage/storage-engines/s3-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Integrate MariaDB Server with Amazon S3 using the S3 Storage Engine. Learn how to store and retrieve data directly from cloud object storage for scalability and cost efficiency.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/Rmtv96UgLgZ2bVkO855v" %}
[SphinxSE](/docs/server/server-usage/storage-engines/sphinx-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Integrate MariaDB Server with Sphinx for advanced full-text search. The Sphinx storage engine allows you to query external Sphinx indexes directly from your database.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/xa3MMCkKDNE4V3EDCvAR" %}
[Spider](/docs/server/server-usage/storage-engines/spider.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Explore the Spider storage engine in MariaDB Server. Learn how to shard data across multiple MariaDB and MySQL servers, enabling horizontal scaling and distributed database solutions.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/2XZk4CL7U7Qeeb9WDKq2" %}
[TideSQL](/docs/server/server-usage/storage-engines/tidesql.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
TideSQL is a transactional, log-structured merge-tree storage engine built on the TidesDB library, optimized for high write throughput with full SQL, MVCC, encryption, and secondary, spatial, full-text, and vector indexes.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/nuKDynnmdCJvckYkVaby" %}
[VIDEX Storage Engine](/docs/server/server-usage/storage-engines/videx-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The VIDEX storage engine is an aggregated, extensible engine suitable for what-if analyses in MariaDB. The name is derived from \[VI]rtual in\[DEX].
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/2yvxiEWS8KGSblfFYXaX" %}
[Converting Tables from MyISAM to InnoDB](/docs/server/server-usage/storage-engines/converting-tables-from-myisam-to-innodb.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
This guide outlines the benefits and process of migrating tables from MyISAM to InnoDB, highlighting key differences like transaction support and foreign keys.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/zIQCxzLsZLACzfdpGQRP" %}
[Machine Learning with MindsDB](/docs/server/server-usage/storage-engines/machine-learning-with-mindsdb.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
Learn how to integrate MindsDB with MariaDB to train and query machine learning models directly using standard SQL commands.
{% endcolumn %}
{% endcolumns %}

{% columns %}
{% column %}
{% content-ref url="/pages/AVLmMoeyLilAv8DriUhc" %}
[FEDERATED Storage Engine](/docs/server/server-usage/storage-engines/federated-storage-engine.md)
{% endcontent-ref %}
{% endcolumn %}

{% column %}
The legacy FEDERATED storage engine, superseded by the actively maintained FederatedX fork.
{% endcolumn %}
{% endcolumns %}

<sub>*This page is licensed: CC BY-SA / Gnu FDL*</sub>
