> For the complete documentation index, see [llms.txt](https://mariadb.com/docs/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://mariadb.com/docs/server/server-usage/storage-engines/innodb/innodb-storage-engine-introduction.md).

# InnoDB Introduction

An overview of the InnoDB storage engine, detailing its support for ACID transactions, row-level locking, and crash recovery.

## Overview

MariaDB Enterprise Server uses the InnoDB storage engine by default. InnoDB is a general purpose transactional storage engine that is performant, ACID-compliant, and well-suited for most workloads.

## Benefits

The InnoDB storage engine:

* Is available with all versions of [MariaDB Enterprise Server](/docs/release-notes/enterprise-server/about/mariadb-enterprise-server-differences.md) and MariaDB Community Server.
* Is a general purpose storage engine.
* Is transactional and well-suited for online transactional processing (OLTP) workloads.
* Is ACID-compliant.
* Performs well for mixed read-write workloads.
* Supports online DDL.

## Feature Summary

| Feature                 | Detail                 | Resources                                                                                                                                                                                                                                                         |
| ----------------------- | ---------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Storage Engine          | InnoDB                 |                                                                                                                                                                                                                                                                   |
| Availability            | All ES and CS versions | [MariaDB Enterprise Server](https://mariadb.com/docs/platform/)                                                                                                                                                                                                   |
| Workload Optimization   | Transactional          |                                                                                                                                                                                                                                                                   |
| Table Orientation       | Row                    |                                                                                                                                                                                                                                                                   |
| Default Row Format      | Dynamic                | [InnoDB Row Formats](/docs/server/server-usage/storage-engines/innodb/innodb-row-formats.md) [InnoDB Dynamic Row Format](/docs/server/server-usage/storage-engines/innodb/innodb-row-formats/innodb-dynamic-row-format.md)                                        |
| ACID-compliant          | Yes                    |                                                                                                                                                                                                                                                                   |
| XA Transactions         | Yes                    |                                                                                                                                                                                                                                                                   |
| Primary Keys            | Yes                    | InnoDB Primary Keys                                                                                                                                                                                                                                               |
| Auto-Increment          | Yes                    | [InnoDB AUTO\_INCREMENT Columns](/docs/server/server-usage/storage-engines/innodb/auto_increment-handling-in-innodb.md)                                                                                                                                           |
| Sequences               | Yes                    | InnoDB Sequences                                                                                                                                                                                                                                                  |
| Foreign Keys            | Yes                    | InnoDB [Foreign Keys](/docs/server/architecture/server-constraints/foreign-key-constraints.md)                                                                                                                                                                    |
| Indexes                 | Yes                    | InnoDB Indexes                                                                                                                                                                                                                                                    |
| Secondary Indexes       | Yes                    | InnoDB Secondary Indexes                                                                                                                                                                                                                                          |
| Unique Indexes          | Yes                    | InnoDB Unique Indexes                                                                                                                                                                                                                                             |
| Full-text Search        | Yes                    | InnoDB Full-text Indexes                                                                                                                                                                                                                                          |
| Spatial Indexes         | Yes                    | InnoDB Spatial Indexes                                                                                                                                                                                                                                            |
| Compression             | Yes                    | [Configure InnoDB Page Compression](/docs/server/server-usage/storage-engines/innodb/innodb-page-compression.md)                                                                                                                                                  |
| Data-at-Rest Encryption | Yes                    |                                                                                                                                                                                                                                                                   |
| High Availability (HA)  | Yes                    | • [MariaDB Replication](/docs/server/ha-and-performance/standard-replication.md) • [Galera Cluster](/docs/galera-cluster/readme/mariadb-galera-cluster-usage-guide.md)                                                                                            |
| Main Memory Caching     | Yes                    | [InnoDB Buffer Pool](/docs/server/server-usage/storage-engines/innodb/innodb-buffer-pool.md)                                                                                                                                                                      |
| Transaction Logging     | Yes                    | • [InnoDB Redo Log (Crash Safety)](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-redo-log.md) • [InnoDB Undo Log (MVCC)](/docs/server/server-usage/storage-engines/innodb/innodb-undo-log.md) |
| Garbage Collection      | Yes                    | [InnoDB Purge Threads](/docs/server/server-usage/storage-engines/innodb/innodb-system-variables.md#innodb_purge_threads)                                                                                                                                          |
| Online Schema changes   | Yes                    | [InnoDB Schema Changes](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/schema-changes.md)                                                                                                                           |
| Non-locking Reads       | Yes                    |                                                                                                                                                                                                                                                                   |
| Row Locking             | Yes                    |                                                                                                                                                                                                                                                                   |

## Examples

### Creating an InnoDB Table

```sql
CREATE DATABASE hq_sales;
```

```sql
CREATE TABLE hq_sales.invoices (
   invoice_id BIGINT UNSIGNED AUTO_INCREMENT NOT NULL,
   branch_id INT NOT NULL,
   customer_id INT,
   invoice_date DATETIME(6),
   invoice_total DECIMAL(13, 2),
   payment_method ENUM('NONE', 'CASH', 'WIRE_TRANSFER', 'CREDIT_CARD', 'GIFT_CARD'),
   PRIMARY KEY(invoice_id)
) ENGINE = InnoDB;
```

```sql
SELECT TABLE_SCHEMA, TABLE_NAME, ENGINE
FROM information_schema.TABLES
WHERE TABLE_SCHEMA='hq_sales'
AND TABLE_NAME='invoices';
+--------------+------------+--------+
| TABLE_SCHEMA | TABLE_NAME | ENGINE |
+--------------+------------+--------+
| hq_sales     | invoices   | InnoDB |
+--------------+------------+--------+
```

## Resources

### Architecture

* Background Thread Pool
* [Buffer Pool](/docs/server/server-usage/storage-engines/innodb/innodb-buffer-pool.md)
* [I/O Threads](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-io-threads.md)
* [Purge Threads](/docs/server/server-usage/storage-engines/innodb/innodb-purge.md)
* [Redo Log](/docs/server/server-usage/storage-engines/innodb/innodb-redo-log.md)
* [Row Formats](/docs/server/server-usage/storage-engines/innodb/innodb-row-formats.md)
* [Undo Log](/docs/server/server-usage/storage-engines/innodb/innodb-undo-log.md)

### Operations

* [Configure Page Compression](/docs/server/server-usage/storage-engines/innodb/innodb-page-compression.md)
* [Configure the Buffer Pool](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-buffer-pool.md)
* [Configure the I/O Threads](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-io-threads.md)
* [Configure the Purge Threads](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-purge-threads.md)
* [Configure the Redo Log](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-redo-log.md)
* [Configure the Undo Log](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/configure-the-innodb-undo-log.md)
* [Schema Changes](/docs/server/server-usage/storage-engines/innodb/mariadb-enterprise-server-innodb-operations/schema-changes.md)

## MariaDB documentation

* [InnoDB](/docs/server/server-usage/storage-engines/innodb.md)

<sub>*This page is: Copyright © 2026 MariaDB. All rights reserved.*</sub>

{% @marketo/form formId="4316" %}
