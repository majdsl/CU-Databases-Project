> For the complete documentation index, see [llms.txt](https://mariadb.com/docs/llms.txt). Markdown versions of documentation pages are available by appending `.md` to page URLs; this page is available as [Markdown](https://mariadb.com/docs/server/server-usage/storage-engines/myrocks/myrocks-transactional-isolation.md).

# MyRocks Transactional Isolation

MyRocks storage engine transactional isolatioin.

* MyRocks uses snapshot isolation.
* Support do `READ-COMMITTED` and `REPEATABLE-READ` .
* `SERIALIZABLE` is not supported.
  * There is no "gap locking" which makes Statement Based Replication unsafe (see [MyRocks and Replication](/docs/server/server-usage/storage-engines/myrocks/myrocks-and-replication.md)).

<sub>*This page is licensed: CC BY-SA / Gnu FDL*</sub>

{% @marketo/form formId="4316" %}
